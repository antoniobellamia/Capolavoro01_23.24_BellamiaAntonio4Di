package org.example;

public class DeltaTime extends Thread{
    DeltaTimeInterface mp;
    public DeltaTime(DeltaTimeInterface mp){

        setName("EXECUTION TIME THREAD");
        this.mp=mp;

        this.start();
    }

    @Override
    public void run() {
        while(true){
            int time = Math.round((System.currentTimeMillis()-mp.getStartTime())/1000);
            mp.setDeltaTime(time);
        }
    }
}