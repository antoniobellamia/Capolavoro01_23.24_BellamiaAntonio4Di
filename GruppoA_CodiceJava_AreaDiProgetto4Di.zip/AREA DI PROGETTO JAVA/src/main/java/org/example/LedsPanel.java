package org.example;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.Arrays;

public class LedsPanel extends BufferedPanel implements BufferDataListener {

    private JPanel[] leds;
    private SingleLedPanel[] sl;

    public LedsPanel(Buffer buffer) {
        super(buffer, 0);
        setName("LED panel");
        buffer.addBufferDataListener(this);
        leds = new JPanel[3];
        sl = new SingleLedPanel[3];
        setGraphicalInterface();

        leds[0].setOpaque(false);
        leds[1].setOpaque(false);
        leds[2].setOpaque(false);


    }

    protected void setGraphicalInterface(){
        setBorder(new LineBorder(Color.black));
        setVisible(true);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        leds[0] = new JPanel();
        leds[1] = new JPanel();
        leds[2]=new JPanel();

        sl[0] = new SingleLedPanel("LED 1", 0, buffer);
        sl[1] = new SingleLedPanel("LED 2", 1, buffer);
        sl[2] = new SingleLedPanel("LED 3", 2, buffer);

        leds[0].add(sl[0]);
        leds[1].add(sl[1]);
        leds[2].add(sl[2]);

        // Pannello A
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        add(leds[0], gbc);

        // Pannello B
        gbc.gridx = 1;
        add(leds[1], gbc);

        // Pannello C
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(leds[2], gbc);


    }

    @Override
    public void BufferDataChange(BufferDataEvent e) {
        if(e.getProperty() instanceof SafeModeInputException){
            sl[0].setLblStatus(-1);
            sl[1].setLblStatus(-1);
            sl[2].setLblStatus(-1);
        }

        if(e.getProperty() instanceof Integer && (int) e.getProperty() == PROTOCOL_CODE){
            try {

                super.readBuffer();
                if(!bits[7]) return;

                boolean[] blLedID = {bits[3], bits[4]};
                boolean[] blLedSts = {bits[5], bits[6]};

                int ledId = 0;//booleanArrayToIntConverter(blLedID);
                int ledSts = 0;//booleanArrayToIntConverter(blLedSts);

                if(bits[3]) ledId+=2;
                if(bits[4]) ledId++;
                if(bits[5]) ledSts+=2;
                if(bits[6]) ledSts++;




                System.out.println("LED ID = "+ledId + "ledSts= "+ledSts);
                sl[ledId].setLblStatus(ledSts);


            }catch(Exception exc){
                System.out.println(Arrays.toString(exc.getStackTrace()));
            }
        }
    }
}
