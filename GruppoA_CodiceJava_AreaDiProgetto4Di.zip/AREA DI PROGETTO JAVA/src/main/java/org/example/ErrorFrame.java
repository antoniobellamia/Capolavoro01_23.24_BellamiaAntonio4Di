package org.example;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;

public class ErrorFrame extends JFrame {

    Clip clip;

    public ErrorFrame() {
        try {


            JPanel panel = getjPanel();

            // Aggiungi il pannello al JFrame
            add(panel);

            pack();

            setVisible(true);

            audioOnly();

            setSize(950, 630);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public ErrorFrame(Object ob){

    }

    private JPanel getjPanel() {
        ImageIcon imageIcon = new ImageIcon("src\\main\\java\\org\\example\\error_screen.png");

        // Crea un pannello personalizzato con sfondo
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Disegna l'immagine di sfondo
                g.drawImage(imageIcon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(new BorderLayout());


        return panel;
    }

    public void audioOnly(){

        try {

            AudioInputStream audioInputStream;
            String filePath = "src\\main\\java\\org\\example\\error_sound.wav";

            audioInputStream =
                    AudioSystem.getAudioInputStream(new File(filePath).getAbsoluteFile());

            // create clip reference
            clip = AudioSystem.getClip();

            // open audioInputStream to the clip
            clip.open(audioInputStream);
            clip.start();

        } catch (Exception ec){
        }

    }

    public void stopAudio(){
        try {

            if(clip!=null && clip.isActive() && clip.isRunning())
                clip.stop();

        } catch (Exception ec){
        }
    }
}
