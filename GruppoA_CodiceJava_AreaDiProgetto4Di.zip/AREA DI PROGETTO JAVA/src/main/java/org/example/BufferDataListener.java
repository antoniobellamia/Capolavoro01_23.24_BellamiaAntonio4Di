package org.example;

import java.util.EventListener;

public interface BufferDataListener extends EventListener {
    void BufferDataChange(BufferDataEvent e);

}
