package org.example;

import com.fazecast.jSerialComm.SerialPort;

import java.util.Arrays;

public class SerialCommInputManager  extends Thread{

    SerialPort openedPort;
    Buffer buffer;
    int port = 0; // array index to select COM port

    public SerialCommInputManager(Buffer buffer){
        setName("SerialCommInputManager Thread");
        setPriority(MAX_PRIORITY);

        SerialPort[] comPorts = SerialPort.getCommPorts();
        System.out.println("PORTE DISPONIBILI: " + comPorts.length);
        this.buffer = buffer;

        try{

            comPorts[port].openPort();

            System.out.println("PORTA APERTA: n "+port+" = "+comPorts[port].openPort());

            openedPort = comPorts[port];
            buffer.setSerialPort(openedPort);

            this.start();

        }catch(Exception exc){
            System.out.println(Arrays.toString(exc.getStackTrace()));
            buffer.fireBufferDataChange(new SafeModeInputException(exc.getMessage()));
            SafeModeOutputException.showCustomErrorMessage(2);
        }


    }

    @Override
    public void run() {

        while(true) {

            try {

                Thread.sleep(5000);

                byte[] readBytes = new byte[openedPort.bytesAvailable()];
                openedPort.readBytes(readBytes, readBytes.length);
                for(int i=0; i<readBytes.length; i++) {
                    //System.out.println("Numread=" + readBytes[i]);
                    buffer.setRecByte(readBytes[i]);
                }

            } catch (Exception e) {
                System.out.println(Arrays.toString(e.getStackTrace()));
                buffer.fireBufferDataChange(new SafeModeInputException(/*e.getMessage())*/"DISCONNECTED"));
            }

        }
    }

}
