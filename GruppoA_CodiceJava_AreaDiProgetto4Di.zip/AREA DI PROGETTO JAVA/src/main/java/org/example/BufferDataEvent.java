package org.example;

import java.util.EventObject;

public class BufferDataEvent extends EventObject {
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */

    private Object property=null;

    public BufferDataEvent(Object source) {
        super(source);
    }

    public BufferDataEvent(Object source, Object property) {
        super(source);
        this.property=property;
    }

    public Object getProperty() {
        return property;
    }
}
