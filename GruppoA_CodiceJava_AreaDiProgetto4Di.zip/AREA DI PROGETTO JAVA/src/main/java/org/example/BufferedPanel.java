package org.example;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Arrays;

public class BufferedPanel extends JPanel {
    protected Buffer buffer;
    protected Color bgColor;
    protected boolean[] bits;
    public final int PROTOCOL_CODE;

    public BufferedPanel(Buffer buffer, int PROTOCOL_CODE){
        this.buffer = buffer;
        bgColor = new Color(26, 35, 100);
        setBackground(bgColor);
        this.PROTOCOL_CODE=PROTOCOL_CODE;

    }

    public void readBuffer(){
        if(buffer.isUnread()) {
            if (buffer.getMsgCode() == PROTOCOL_CODE) {
                bits = buffer.getBits();
                buffer.setRead();
            }
        }
    }

    public static boolean[] intToBooleanArrayConverter(int val, int lenght){
        boolean[] b = new boolean[lenght];

        for(int i=b.length-1; val>0 && i>=0; val/=2, i--){
            if(val%2==1) b[i]=true;
            else b[i]=false;
        }

        return b;
    }

    public static int booleanArrayToIntConverter(boolean[] b){
        int val=0;

        for(int i=0; i<b.length; i++){
            if(b[i])
                val+= (int) (Math.pow(2, b.length-i-1));
        }

        return val;
    }
}
