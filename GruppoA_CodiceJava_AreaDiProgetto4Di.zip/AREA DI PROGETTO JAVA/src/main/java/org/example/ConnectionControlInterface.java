package org.example;

public interface ConnectionControlInterface {
    public long getLastUpdated();
}
