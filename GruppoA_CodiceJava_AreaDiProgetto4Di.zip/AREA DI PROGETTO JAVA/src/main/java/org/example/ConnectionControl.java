package org.example;

public class ConnectionControl extends Thread{
    StatusPanels sp;

    public ConnectionControl(StatusPanels sp){

        if(sp!=null) this.sp=sp;

        this.start();
    }


    @Override
    public void run() {
        while(true){

            long delta = System.currentTimeMillis()-sp.getLastUpdated();

            if(delta>15000 && sp.isConnected()){
                sp.setLblStatusDisplay(3);
            }
        }
    }
}
