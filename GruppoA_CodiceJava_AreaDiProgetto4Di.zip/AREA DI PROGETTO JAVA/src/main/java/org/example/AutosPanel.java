package org.example;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class AutosPanel extends BufferedPanel implements ActionListener, BufferDataListener {
    private String[] values;

    JLabel lblLuminosità;
    JButton autoOn;
    JComboBox<String> cmbLuminosità;
    JPanel pnlAutos, pnlLuminosità;

    public AutosPanel(Buffer buffer) {
        super(buffer, 3);
        setName("AutosPanel");
        buffer.addBufferDataListener(this);
        setValues();

        setGraphicalInterface();

        autoOn.addActionListener(this);
        cmbLuminosità.addActionListener(this);

    }

     private void setGraphicalInterface(){
        setBorder(new LineBorder(Color.black, 1));
        setVisible(true);
        setLayout(new GridLayout(1, 2));

        autoOn = new JButton("<html> <h1> &nbsp&nbsp ATTIVA AUTOMAZIONE&nbsp&nbsp </h1>");
        lblLuminosità = new JLabel("<html> <h1> LUMINOSITA' MINIMA: </h1>", JLabel.RIGHT);

        pnlAutos = new JPanel();
        add(pnlAutos);
        pnlAutos.setLayout(new FlowLayout(FlowLayout.LEFT));
        pnlAutos.add(autoOn);
        pnlAutos.setBackground(bgColor);

        autoOn.setBorder(BorderFactory.createRaisedBevelBorder());


        cmbLuminosità = new JComboBox<String>(values);
        cmbLuminosità.setMaximumRowCount(cmbLuminosità.getItemCount());


        pnlLuminosità = new JPanel(); add(pnlLuminosità);
        pnlLuminosità.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlLuminosità.add(lblLuminosità);
        pnlLuminosità.add(cmbLuminosità);

        pnlLuminosità.setBackground(bgColor);


        lblLuminosità.setForeground(Color.WHITE);
    }


    public void setValues() {
        values = new String[11];
        values[0]="1%";
        values[10]="AUTO OFF";

        for(int i=1; i<10; i++ ){
            values[i]=""+(i*10)+"%";
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== autoOn){
            boolean[] b = {true, true, true, true, true, true, true, true};
            System.out.println(Arrays.toString(b));
            new SendData(buffer, b);

        }

        if(e.getSource()== cmbLuminosità){
            int selected = cmbLuminosità.getSelectedIndex();
            boolean[] bMsg = new boolean[4];
            if(selected<=10)
                bMsg = intToBooleanArrayConverter(selected, 4);

            boolean[] b = {true, true, false, bMsg[0], bMsg[1], bMsg[2], bMsg[3], false};
            System.out.println(Arrays.toString(b));
            new SendData(buffer, b);
        }
    }

    @Override
    public void BufferDataChange(BufferDataEvent e) {
        if(e.getProperty() instanceof Integer && (int) e.getProperty() == PROTOCOL_CODE){

            try {
                super.readBuffer();

                boolean[] dataBl = {bits[3], bits[4], bits[5], bits[6]};
                int value = booleanArrayToIntConverter(dataBl);

                if (value != cmbLuminosità.getSelectedIndex() && value < cmbLuminosità.getMaximumRowCount())
                    cmbLuminosità.setSelectedIndex(value);

            }catch(Exception exc){
            System.out.println(Arrays.toString(exc.getStackTrace()));
        }
        }
    }
}
