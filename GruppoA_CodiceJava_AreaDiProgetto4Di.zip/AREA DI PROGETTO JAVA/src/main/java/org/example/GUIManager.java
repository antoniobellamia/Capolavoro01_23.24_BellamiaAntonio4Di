package org.example;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class GUIManager implements WindowListener {
    Buffer buffer;

    public GUIManager(Buffer buffer){
        this.buffer=buffer;
        Frame1 frame = new Frame1(buffer);
        frame.addWindowListener(this);
    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {

    }

    @Override
    public void windowClosed(WindowEvent e) {
        buffer.closePort();
        System.out.println("buffer.closePort();");
        System.exit(0);
    }


    @Override
    public void windowIconified(WindowEvent e) {
    }
    @Override
    public void windowDeiconified(WindowEvent e) {

    }
    @Override
    public void windowActivated(WindowEvent e) {

    }
    @Override
    public void windowDeactivated(WindowEvent e) {

    }

}
