package org.example;

import com.fazecast.jSerialComm.*;

import java.util.Arrays;

public class SendData{
    SerialPort serialPort;
    public SendData(Buffer buffer, boolean[] bits){
        try {
            serialPort = buffer.getSerialPort();

            byte[] writeByte = {booleanToByte(bits)};
            serialPort.writeBytes(writeByte, writeByte.length);
        }catch(Exception e){
            System.out.println(Arrays.toString(e.getStackTrace()));
            buffer.fireBufferDataChange(new SafeModeOutputException(e.getMessage()));
        }
    }

    public static byte booleanToByte(boolean[] array) {
        byte val = 0;
        for (boolean b : array) {
            val <<= 1;
            if (b)
                val |= 1;
        }//from  w  ww  . ja v  a  2  s  .c  o  m
        return val;
    }
}
