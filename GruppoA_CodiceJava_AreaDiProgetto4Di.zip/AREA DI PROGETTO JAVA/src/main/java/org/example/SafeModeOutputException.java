package org.example;
import javax.swing.*;

public class SafeModeOutputException extends RuntimeException {

    public SafeModeOutputException() {
    }

    public SafeModeOutputException(String message) {
        super(message);
    }

    public static void showCustomErrorMessage(int i){

        new ErrorFrame();

        if(i==2)
            JOptionPane.showMessageDialog(null, "A FATAL ERROR HAS OCCURRED", "SAFE MODE FAILURE", JOptionPane.ERROR_MESSAGE);
    }
}

