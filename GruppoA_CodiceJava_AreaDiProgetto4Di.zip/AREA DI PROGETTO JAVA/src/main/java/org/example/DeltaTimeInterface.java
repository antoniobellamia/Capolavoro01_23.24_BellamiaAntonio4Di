package org.example;

public interface DeltaTimeInterface {
    public void setDeltaTime(int time);
    public long getStartTime();
}
