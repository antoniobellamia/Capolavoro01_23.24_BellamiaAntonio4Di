package org.example;

public class SafeModeInputException extends RuntimeException{

    public SafeModeInputException() {
        super();
    }

    public SafeModeInputException(String message) {
        super(message);
    }
}
