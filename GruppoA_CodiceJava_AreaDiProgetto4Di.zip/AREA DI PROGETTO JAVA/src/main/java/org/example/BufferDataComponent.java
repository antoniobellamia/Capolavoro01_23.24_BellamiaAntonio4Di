package org.example;

import java.util.ArrayList;
import java.util.List;

public class BufferDataComponent {
    private List<BufferDataListener> listeners = new ArrayList<>();

    public void addBufferDataListener(BufferDataListener bufferDataListener){
        listeners.add(bufferDataListener);
    }

    public void removeBufferDataListener(BufferDataListener bufferDataListener){
        listeners.remove(bufferDataListener);
    }

    public void fireBufferDataChange(Object newProperty){
        BufferDataEvent event = new BufferDataEvent(this, newProperty);
        for(BufferDataListener listener : listeners){
            listener.BufferDataChange(event);
        }
    }
}
