package org.example;

import javax.swing.*;
import java.awt.*;

public class MainPanel extends BufferedPanel implements DeltaTimeInterface{

    BufferedPanel pnlStatus, pnlAutos, pnlLeds, pnlServo;
    FooterPanel pnlFooter;
    public final long startTime = System.currentTimeMillis();

    public MainPanel(Buffer buffer) {
        super(buffer, -1);
        setName("MainPanel");
        setBackground(Color.gray);

        BoxLayout bxl = new BoxLayout(this, BoxLayout.Y_AXIS);
        setLayout(bxl);

        pnlStatus = new StatusPanels(buffer);
        add(pnlStatus);
        pnlStatus.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        pnlAutos = new AutosPanel(buffer);
        add(pnlAutos);
        pnlAutos.setMinimumSize(new Dimension(Integer.MAX_VALUE, 50));
        pnlAutos.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

        pnlLeds=new LedsPanel(buffer);
        pnlServo=new ServoPanel(buffer);

        JPanel centralP = new JPanel();
        centralP.setLayout(new GridLayout(1,2));
        add(centralP);
        centralP.add(pnlLeds);
        centralP.add(pnlServo);

        pnlFooter = new FooterPanel(buffer);
        add(pnlFooter);

        new DeltaTime(this);
        pnlFooter.setMaximumSize(new Dimension(Integer.MAX_VALUE, 10));


    }



    public void setDeltaTime(int time) {
        pnlFooter.setLblTime(time);
    }

    @Override
    public long getStartTime() {
        return startTime;
    }

}
