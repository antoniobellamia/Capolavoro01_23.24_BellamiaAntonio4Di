package org.example;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.Arrays;

public class StatusPanels extends BufferedPanel implements ConnectionControlInterface, BufferDataListener{

    private JLabel lblStatus, lblStatusDisplay, lblLuminosità, lblDisplayLuminosità;
    private JPanel pnlStatus, pnlLuminosità;
    private String statusValue;
    private int luminositàValue=0;
    private boolean isConnected, startingLink=false;
    private ErrorFrame er = new ErrorFrame(false);

    private long lastUpdated = System.currentTimeMillis();

    public StatusPanels(Buffer buffer){
        super(buffer, 2);
        setName("StatusPanel");
        buffer.addBufferDataListener(this);

        setGraphicalInterface();

        new ConnectionControl(this);
    }

    private void setGraphicalInterface(){
        setBorder(new LineBorder(Color.white, 1));
        setVisible(true);
        setLayout(new GridLayout(1, 2));

        lblStatus = new JLabel("<html> <h1> STATUS: </h1></html>", JLabel.LEFT);
        lblStatusDisplay = new JLabel("", JLabel.LEFT);
        setLblStatusDisplay(startingLink);
        lblLuminosità = new JLabel("<html> <h1> LUMINOSITA' ATTUALE: </h1>", JLabel.RIGHT);
        lblDisplayLuminosità = new JLabel("<html> <h1>"+luminositàValue+" </h1>", JLabel.RIGHT);

        pnlStatus = new JPanel();
        add(pnlStatus);
        pnlStatus.setLayout(new FlowLayout(FlowLayout.LEFT));
        pnlStatus.add(lblStatus);
        pnlStatus.add(lblStatusDisplay);
        pnlStatus.setBackground(bgColor);

        pnlLuminosità = new JPanel(); add(pnlLuminosità);
        pnlLuminosità.setLayout(new FlowLayout(FlowLayout.RIGHT));
        pnlLuminosità.add(lblLuminosità);
        pnlLuminosità.add(lblDisplayLuminosità);
        pnlLuminosità.setBackground(bgColor);

        lblStatus.setForeground(Color.WHITE);
        lblStatusDisplay.setForeground(Color.WHITE);
        lblLuminosità.setForeground(Color.WHITE);
        lblDisplayLuminosità.setForeground(Color.WHITE);

    }

    private void setLuminositàValue(int lumValue) {
        if(lumValue>=0) {
            luminositàValue = lumValue;
            lblDisplayLuminosità.setText("<html> <h1>" + luminositàValue + "% </h1>");
        }else
            lblDisplayLuminosità.setText("<html> <h1> NO DATA </h1>");
    }

    public void setLblStatusDisplay(boolean sts) {

        boolean prec = isConnected;

        if (sts) {
            statusValue = "ON <span style=\"color: #00ff00\">☻▲</span>";
            isConnected=true;
            er.stopAudio();
        } else{
            statusValue = "OFF <span style=\"color: red\">▼</span>";

            isConnected=false;
            lastUpdated = 0;

        }

        lblStatusDisplay.setText("<html> <h1>" + statusValue + " </h1></html>");
        if(prec && !isConnected) er.audioOnly();

    }

    public void setLblStatusDisplay(int idle) {

        statusValue = "<span style=\"color: orange\">IDLE ◄►</span>";
        lblStatusDisplay.setText("<html> <h1>" + statusValue + " </h1></html>");

    }

    public boolean isConnected() {
        return isConnected;
    }

    public long getLastUpdated() {
        return lastUpdated;
    }

    @Override
    public void BufferDataChange(BufferDataEvent e) {
        if(e.getProperty() instanceof SafeModeInputException) {
            setLblStatusDisplay(false);
            setLuminositàValue(-1);
        }

        if(e.getProperty() instanceof Integer && (int) e.getProperty() == PROTOCOL_CODE){
            try {

                super.readBuffer();

                setLblStatusDisplay(true);
                lastUpdated = System.currentTimeMillis();

                boolean[] dataBl = {bits[3], bits[4], bits[5], bits[6], bits[7]};
                int value = booleanArrayToIntConverter(dataBl);

                if( (int)Math.round(value * 3.22) != luminositàValue) {
                    luminositàValue = (int) Math.round(value * 3.22);
                    setLuminositàValue(luminositàValue);
                }

            }catch(Exception exc){
                System.out.println(Arrays.toString(exc.getStackTrace()));
            }
        }
    }
}
