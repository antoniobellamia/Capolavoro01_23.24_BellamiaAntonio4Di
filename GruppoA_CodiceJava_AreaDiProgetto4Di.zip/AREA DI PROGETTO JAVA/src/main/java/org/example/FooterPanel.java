package org.example;

import javax.swing.*;
import java.awt.*;

public class FooterPanel extends BufferedPanel implements BufferDataListener{
    JLabel lblTime, info;
    JPanel pnlInfo, pnlTime;

    public FooterPanel(Buffer buffer){
        super(buffer, -1);
        setBackground(Color.WHITE);
        buffer.addBufferDataListener(this);
        setVisible(true);
        setLayout(new GridLayout(1, 2));
        info = new JLabel();
        lblTime = new JLabel();

        pnlInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlTime = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        pnlInfo.setVisible(true);
        pnlTime.setVisible(true);

        pnlInfo.add(info);
        pnlTime.add(lblTime);

        add(pnlInfo);
        add(pnlTime);
    }

    public String getLblTime() {
        return lblTime.getText();
    }

    public void setLblTime(long time) {
        lblTime.setText("EXECUTION TIME: "+time+"s");
    }

    public void setInfo(String txt){
        info.setText(txt);
    }

    public String getInfo(){
        return info.getText();
    }

    @Override
    public void BufferDataChange(BufferDataEvent e) {
        if(e.getProperty() instanceof SafeModeOutputException){
            info.setText("<html><span style=\"color:orange\">COM ERROR</span>: "+ ((SafeModeOutputException) e.getProperty()).getMessage());

        }else if(e.getProperty() instanceof SafeModeInputException){

            info.setText("<html><span style=\"color:red\">SAFE MODE RUNNING</span>: "+ ((SafeModeInputException) e.getProperty()).getMessage());

        }else info.setText("<html>SERIAL COMMUNICATION IS <span style=\"color:green\">NOMINAL ");
    }
}
