package org.example;

public class Main {
    public static void main(String[] args){

        try {

            Buffer buffer = new Buffer();

            new GUIManager(buffer);
            new SerialCommInputManager(buffer);

            //throw new Exception();

        }catch (Exception | Error ex) {
            SafeModeOutputException.showCustomErrorMessage(2);
            ex.printStackTrace();
        }
    }
}