package org.example;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class ServoPanel extends BufferedPanel implements ActionListener, BufferDataListener{

    JComboBox<String> cmbRotazione;
    JLabel lblRotazioneAttuale, lblText;
    String[] values;

    public ServoPanel(Buffer buffer) {
        super(buffer, 1);
        setName("ServoPanel");
        buffer.addBufferDataListener(this);
        setGraphicalInterface();

        cmbRotazione.addActionListener(this);
    }

    private void setGraphicalInterface(){
        JPanel pnl2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        setBorder(new LineBorder(Color.black, 1));
        setVisible(true);

        setValues();

        lblText= new JLabel("<html><h1>SELEZIONA IL GRADO DI ROTAZIONE:");
        cmbRotazione = new JComboBox<String>(values);
        cmbRotazione.setMaximumRowCount(cmbRotazione.getItemCount());
        cmbRotazione.setSelectedIndex(16);
        lblRotazioneAttuale = new JLabel();
        setLblRotazioneAttuale(0);

        lblRotazioneAttuale.setForeground(Color.WHITE);
        lblText.setForeground(Color.WHITE);

        pnl2.add(lblText);
        pnl2.add(cmbRotazione);
        pnl2.setBackground(bgColor);

        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 10, 10, 10); // Spazio intorno ai pannelli

        add(lblRotazioneAttuale, gbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(0, 10, 10, 10); // Solo spazio inferiore
        add(pnl2, gbc);

    }

    public void setLblRotazioneAttuale(int degree) {
        if(degree >= 0)
            lblRotazioneAttuale.setText("<html><h1>ROTAZIONE ATTUALE: "+degree+"°");
        else
            lblRotazioneAttuale.setText("<html><h1>ROTAZIONE ATTUALE NON PERVENUTA");
    }

    private void setValues() {
        values = new String[17];

        values[values.length-1] = "AUTO ON";

        for(int i=0; i< values.length-1; i++){

            values[i] = ""+(i*6)+"°";
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==cmbRotazione){

            int sel = cmbRotazione.getSelectedIndex();

            if(sel>=16){
                boolean[] b={true, false, true, true, false, false, false, false};
                new SendData(buffer, b);
                System.out.println(Arrays.toString(b));
            }else{
                boolean[] d = intToBooleanArrayConverter(sel, 4);
                boolean[] b = {true, false, true, false, d[0], d[1], d[2], d[3]};
                new SendData(buffer, b);
                System.out.println(Arrays.toString(b));
            }

        }
    }

    @Override
    public void BufferDataChange(BufferDataEvent e) {

        if(e.getProperty() instanceof SafeModeInputException){
            setLblRotazioneAttuale(-1);
        }

        if(e.getProperty() instanceof Integer && (int) e.getProperty() == PROTOCOL_CODE){
            try {

                super.readBuffer();

                boolean[] dataBl = {bits[4], bits[5], bits[6], bits[7]};
                //System.out.println(Arrays.toString(bits));
                //System.out.println(Arrays.toString(dataBl));
                int value = booleanArrayToIntConverter(dataBl);
                int realValue = value * 6;

                //System.out.println(value);

                setLblRotazioneAttuale(realValue);

            }catch(Exception exc){
                System.out.println(Arrays.toString(exc.getStackTrace()));
            }
        }
    }
}