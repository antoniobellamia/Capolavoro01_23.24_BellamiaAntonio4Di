package org.example;

import javax.swing.*;
import java.awt.*;


public class Frame1 extends JFrame {
    Buffer buffer;

    BufferedPanel mainPanel;

    public Frame1(Buffer buffer){
        setDefaultSettings();
        this.buffer = buffer;
        mainPanel=new MainPanel(buffer);
        add(mainPanel);

    }

    protected void setDefaultSettings(){
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(500, 500);
        setMinimumSize(new Dimension(950, 650));
    }


}
