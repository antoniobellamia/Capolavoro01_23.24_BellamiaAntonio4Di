package org.example;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class SingleLedPanel extends JPanel implements ActionListener {

    JPanel mainPanel, pnlDisplay, pnlSelect;
    JLabel lblLedName, lblStatus;
    CardLayout crd;
    JButton btn, btnOn, btnOff, btnAuto;
    boolean[] code;
    Buffer buffer;


    public SingleLedPanel(String ledName, int code, Buffer buffer){
        setVisible(true);
        setName(ledName);
        this.code = BufferedPanel.intToBooleanArrayConverter(code, 2);
        this.buffer=buffer;
        crd=new CardLayout();

        setLayout(new OverlayLayout(this));

        mainPanel = new JPanel(crd);
        add(mainPanel);

        btn = new JButton("<html><h1></h1><h1></h1>");
        JPanel pnlB = new JPanel(new BorderLayout());
        pnlB.add(btn);
        add(pnlB);
        btn.addActionListener(this);

        pnlB.setOpaque(false);
        setBackButtons();
        setPnlDisplay();
        setPnlSelect();

    }

    private void setBackButtons(){
        btn.setEnabled(true);
        btn.setVisible(true);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
    }

    private void setPnlSelect() {
        pnlSelect = new JPanel(new GridBagLayout());
        mainPanel.add(pnlSelect);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH; // Riempimento orizzontale e verticale

        // Primo pulsante (btnOn)
        btnOn = new JButton("ON");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1; // 1 cella
        pnlSelect.add(btnOn, gbc);

        // Secondo pulsante (btnOff)
        btnOff = new JButton("OFF");
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1; // 1 cella
        pnlSelect.add(btnOff, gbc);

        // Terzo pulsante (btnAuto)
        btnAuto = new JButton("AUTO");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // 2 celle per riempire tutta la riga
        pnlSelect.add(btnAuto, gbc);

        btnOff.addActionListener(this);
        btnOn.addActionListener(this);
        btnAuto.addActionListener(this);
    }

    private void setPnlDisplay(){
        pnlDisplay = new JPanel(new GridLayout(2, 1));
        mainPanel.add(pnlDisplay);

        lblLedName = new JLabel("<html><h1>" + getName(), JLabel.CENTER);
        lblStatus = new JLabel("---");
        pnlDisplay.add(lblLedName);
        pnlDisplay.add(lblStatus);

        setLblStatus(4);
    }

    public void setLblStatus(int sts) {
        String dv = "NO DATA";
        Color color;
        switch (sts){
            case 0: dv="MANUAL - <span style=\"color: red\"> OFF </span>";
                color = Color.RED;
            break;

            case 1: dv="MANUAL - <span style=\"color: green\"> ON </span>";
                color = Color.GREEN;
            break;

            case 2: dv="AUTO - <span style=\"color: red\"> OFF </span>";
                color = Color.RED;
            break;

            case 3: dv="AUTO - <span style=\"color: green\"> ON </span>";
                color = Color.GREEN;
            break;

            default: dv="<span style=\"color: black\">"+dv+"</span>";
                color = Color.black;
            break;
        }

        setBorder(BorderFactory.createLineBorder(color, 10));

        lblStatus.setText("<html><h2 style=\"color: green\">"+ dv +"</h2></html>");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btn){
            crd.next(mainPanel);
        }

        if(e.getSource() == btnOn){
            boolean[] msg = {true, false, false, code[0], code[1], false, true, false};
            System.out.println(Arrays.toString(msg));
            new SendData(buffer, msg);
            crd.next(mainPanel);
            //setLblStatus(1);
        }

        if(e.getSource() == btnOff){
            boolean[] msg = {true, false, false, code[0], code[1], false, false, false};
            System.out.println(Arrays.toString(msg));
            new SendData(buffer, msg);
            crd.next(mainPanel);
            //setLblStatus(0);
        }

        if(e.getSource() == btnAuto){
            boolean[] msg = {true, false, false, code[0], code[1], true, true, false};
            System.out.println(Arrays.toString(msg));
            new SendData(buffer, msg);
            crd.next(mainPanel);
            //setLblStatus(2);
        }
    }
}