package org.example;
import com.fazecast.jSerialComm.*;

import java.util.Arrays;

public class Buffer extends BufferDataComponent{
    public static int BIT=8;
    private byte recByte;
    private boolean[] bits;
    private volatile boolean isUnread;
    private int msgCode;

    private SerialPort serialPort;

    public Buffer(){
        bits =new boolean[BIT];
    }


    public synchronized boolean[] getBits() {
        return bits;
    }

    public synchronized void setRecByte(byte recByte) {

        this.recByte = recByte;
        bits = byteToBooleanArray(this.recByte);
        setUnread();
        msgCode = 0;

        if(bits[1]) msgCode+=2;
        if(bits[2]) msgCode+=1;


        //System.out.println("FIRE "+msgCode);
        fireBufferDataChange(msgCode);

    }

    public synchronized byte getRecByte() {
        return recByte;
    }

    public synchronized int getMsgCode() {
        return msgCode;
    }

    public static boolean[] byteToBooleanArray(byte myByte) {
        boolean[] conv=new boolean[BIT];

        for (int i = BIT-1; i>=0; i--) {
            conv[i] = (myByte >>> i & 1) == 1;
        }

        return conv;
    }

    public synchronized void setRead(){
        isUnread=false;
    }

    public synchronized void setUnread(){
        isUnread=true;
    }

    public synchronized boolean isUnread() {
        return isUnread;
    }

    public synchronized void setSerialPort(SerialPort serialPort){
        if(serialPort!=null)
            this.serialPort=serialPort;
    }

    public synchronized SerialPort getSerialPort() {
        return serialPort;
    }

    public synchronized void closePort(){
        try {
            serialPort.closePort();
        } catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }
    }

}
